export class RegisterUser {
    userName:string;
    password:string;
}
