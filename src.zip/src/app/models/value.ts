export class Value {
    id:number;
    name:string;
}
