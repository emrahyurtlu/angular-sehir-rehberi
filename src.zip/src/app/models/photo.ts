export class Photo {
    id:number;
    cityId:number;
    dateAdded:Date;
    description:string;
    isMain:boolean;
    url:string;
}
